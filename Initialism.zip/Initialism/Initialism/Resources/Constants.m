//
//  Constants.m
//  Initialism
//
//  Created by Anurag on 3/8/16.
//  Copyright © 2016 Anurag. All rights reserved.
//

#import "Constants.h"

NSString * const AIBaseURL = @"http://www.nactem.ac.uk/software/acromine/dictionary.py?";
NSString * const kAppFontName = @"HelveticaNeue";
NSString * const kAppBoldFontName = @"HelveticaNeue-Bold";
@implementation Constants

@end
