//
//  IAcronym.m
//  Initialism
//
//  Created by Anurag on 3/8/16.
//  Copyright © 2016 Anurag. All rights reserved.
//

#import "IAcronym.h"

@implementation IAcronym
@synthesize shortForm;
@synthesize meanings;
@end
